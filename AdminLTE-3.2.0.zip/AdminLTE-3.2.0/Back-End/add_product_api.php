<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve form data
  $name = $_POST['name'];
  $price = $_POST['price'];
  $description = $_POST['description'];
  $short_description = $_POST['short_description'];
  $categories = $_POST['category'];

  // Include the WooCommerce API client library
  require __DIR__ . '/vendor/autoload.php';

  // Initialize the WooCommerce client
  $consumer_key = "ck_c6222492ed9890963ed94cb8704514662d133e2a";
  $consumer_secret = "cs_4adc9d2aa9a747177561624c9281b1badebcb2ce";
  $store_url = "https://streamth.co/";

  $woocommerce = new Automattic\WooCommerce\Client(
    $store_url,
    $consumer_key,
    $consumer_secret,
    [
      'version' => 'wc/v3',
    ]
  );

  // Prepare data for creating the product in WooCommerce
  $data = [
    'name' => $name,
    'type' => 'simple',
    'regular_price' => $price,
    'description' => $description,
    'short_description' => $short_description,
    'categories' => [],
    'images' => [
      [
        'src' => '', // We will set the image URL later after upload
      ],
    ],
  ];

  // Add categories
  foreach ($categories as $category_id) {
    $data['categories'][] = ['id' => $category_id];
  }

  // Create the product in WooCommerce
  try {
    // Upload the image file and get the URL
    $uploaded_image = $_FILES['image'];
    $image_url = upload_image($uploaded_image);
    $data['images'][0]['src'] = $image_url;

    // Create the product in WooCommerce with the updated image URL
    $new_product = $woocommerce->post('products', $data);
    echo json_encode(['id' => $new_product->id]);
  } catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
  }
}

function upload_image($uploaded_image) {
  // Check if the product image is valid
  if ($uploaded_image['error'] !== UPLOAD_ERR_OK) {
    return false; // Return false if there is an error in the uploaded image
  }

  // Set the target directory to store the uploaded images
  $target_dir = __DIR__ . '/image/product_images/';

  // Generate a unique filename for the uploaded image to avoid overwriting existing images
  $imageFileName = uniqid() . '_' . $uploaded_image['name'];

  // Move the uploaded image to the target directory
  if (!move_uploaded_file($uploaded_image['tmp_name'], $target_dir . $imageFileName)) {
    return false; // Return false if the image move operation fails
  }

  // Return the URL of the uploaded image
  return 'https://www.streamth.co/AdminLTE-3.2.0/image/product_images/' . $imageFileName;
}

?>
