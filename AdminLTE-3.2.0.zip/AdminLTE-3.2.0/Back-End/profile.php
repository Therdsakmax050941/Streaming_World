<?php
session_start();
$_SESSION['name'] = $name = 'ประหยัด จันอังคาร';
$_SESSION['image'] = $image = '/AdminLTE-3.2.0/image/user1.png';
?>